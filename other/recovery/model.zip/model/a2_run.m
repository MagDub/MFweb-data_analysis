
% a2_main_mod5_sim_normal
% a2_main_mod5_t1_sim_normal

% a2_main_mod6_sim_normal
% a2_main_mod6_t1_sim_normal

% a2_main_mod7_sim_normal
% a2_main_mod7_t1_sim_normal

a2_main_mod8_sim_normal_Q0fixed
a2_main_mod8_t1_sim_normal_Q0fixed

disp('start thomp');

a2_main_mod9_sim_normal
a2_main_mod10_sim_normal
a2_main_mod11_sim_normal
a2_main_mod12_sim_normal